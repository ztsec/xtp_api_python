xtp api的demo测试程序
请将运行目录设置为api文件夹

Demo程序需要配置文件config.json，
请将api文件夹下的config.json文件放入运行目录，
并根据分配的测试账户修改相应的参数
